import { Injectable } from '@angular/core';
import { CartItem } from '../common/cart-item';
import {Subject} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CartService {
  cartItems: CartItem[]=[];
  
  totalPrice: Subject<number>=new Subject<number>();
  totalQuantity: Subject<number>=new Subject<number>();
  constructor() { }
  addtocart(theCartItem:CartItem){

    let alreadyExitsInCart:boolean= false;
    let existingCartItem:CartItem= undefined;
   if (this.cartItems.length>0){
   
   for(let tempCartItem of this.cartItems){
   
     if(tempCartItem.id===theCartItem.id){
       existingCartItem=tempCartItem;
       break;
     }
   }
   alreadyExitsInCart=(existingCartItem!=undefined);
   
   }
   if(alreadyExitsInCart){
     existingCartItem.quantity++;
   }
   else{
     this.cartItems.push(theCartItem);
   }
   this.computeCartTotals();
   
     }
     computeCartTotals(){
       let totalPriceValue:number=0;
       let totalQuantityValue:number=0;
   
   for(let currentCartItem of this.cartItems)
   {
   totalPriceValue =(totalPriceValue)+ (currentCartItem.quantity* currentCartItem.itemprice);
   totalQuantityValue =totalQuantityValue + currentCartItem.quantity;
   
   }
   this.totalPrice.next(totalPriceValue);
   this.totalQuantity.next(totalQuantityValue);
   
   this.poc(totalPriceValue,totalQuantityValue);
   }
   poc(totalPriceValue:Number,totalQuantityValue:Number){
     
     console.log('contents of cart');
   for(let tempCartItem of this.cartItems){
     const subtotalprice=(tempCartItem.quantity*tempCartItem.itemprice);
     console.log('name:'+tempCartItem.name+"  Qantity:"+tempCartItem.quantity+"  itemprice:"+tempCartItem.itemprice+" subprice:"+subtotalprice);
   }
   console.log('tp:'+totalPriceValue+"  totalQantity:"+totalQuantityValue);
   }
   decrementQuantity(theCartItem: CartItem) {

    theCartItem.quantity--;

    if (theCartItem.quantity === 0) {
      this.remove(theCartItem);
    }
    else {
      this.computeCartTotals();
    }
  }

  remove(theCartItem: CartItem) {

    // get index of item in the array
    const itemIndex = this.cartItems.findIndex( tempCartItem => tempCartItem.id === theCartItem.id );

    // if found, remove the item from the array at the given index
    if (itemIndex > -1) {
      this.cartItems.splice(itemIndex, 1);

      this.computeCartTotals();
    }

   
 }
}

