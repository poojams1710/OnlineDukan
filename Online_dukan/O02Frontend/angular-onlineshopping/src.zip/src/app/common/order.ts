export class Order {
  totalPrice: number;
  totalQuantity: number;
}
