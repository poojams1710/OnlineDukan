import { Purchase } from './purchase';

describe('Purchase', () => {
  it('should create an instance', () => {
    expect(new Purchase()).toBeTruthy();
  });
});
