export class Item {

    itemid: number;
    itemname: string;
    description: string;
    itemprice: number;
    stock: number;
    imageurl: string;
    itemcategoryid: number; 
     unitprice:number;


}
