import { ItemCategory } from './item-category';

describe('ItemCategory', () => {
  it('should create an instance', () => {
    expect(new ItemCategory()).toBeTruthy();
  });
});
