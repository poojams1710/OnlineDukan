export class ItemCategory {
  id: number;
  categoryName: string;
}
