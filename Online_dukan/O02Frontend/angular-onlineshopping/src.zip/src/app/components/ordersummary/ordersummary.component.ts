import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ordersummary',
  templateUrl: './ordersummary.component.html',
  styleUrls: ['./ordersummary.component.css']
})
export class OrdersummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
